import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path


def setup_logging() -> None:
    log_dir = Path("logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "automation.log"

    # Handlers
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=100_000,
        backupCount=5,
        encoding="utf-8",
    )
    console_handler = logging.StreamHandler()

    # Formatter (needed when you pass handlers explicitly)
    fmt = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s() - %(message)s"
    )
    file_handler.setFormatter(fmt)
    console_handler.setFormatter(fmt)

    # Apply config (force=True ensures this wins even if something configured logging earlier)
    logging.basicConfig(
        level=logging.INFO,
        handlers=[file_handler, console_handler],
        force=True,
    )


class LoggerImpl:
    @staticmethod
    def get_logger(name: str) -> logging.Logger:
        return logging.getLogger(name)


# ---- Example usage ----
if __name__ == "__main__":
    setup_logging()
    logger = LoggerImpl.get_logger(__name__)
    logger.debug("This is a debug message")  # won't show at INFO
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")

# import logging
# import os
# from datetime import datetime
#
#
# class LogGen:
#     @staticmethod
#     def loggen():
#         logging.basicConfig(filename=".\\Logs\\automation.log",
#                         format='%(asctime)s - %(levelname)s - %(message)s',
#                         datefmt='%d/%m/%Y %I:%M:%S %p')
#         logger = logging.getLogger()
#         logger.setLevel(logging.INFO)
#         return logger
#
# '''class LogGen:
#     @staticmethod
#     def loggen():
#         log_dir = ".\\Logs"
#         os.makedirs(log_dir, exist_ok=True)  # Ensure log directory exists
#         log_file = os.path.join(log_dir, "automation.log")
#
#         logger = logging.getLogger()
#         if not logger.handlers:  # Prevent adding multiple handlers
#             logging.basicConfig(
#                 filename=log_file,
#                 format='%(asctime)s - %(levelname)s - %(message)s',
#                 datefmt='%d/%m/%Y %I:%M:%S %p',
#                 level=logging.INFO
#             )
#
#         return logger'''
