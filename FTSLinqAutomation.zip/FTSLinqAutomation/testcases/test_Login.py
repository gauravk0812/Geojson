import time

import pytest

from Pages.LoginPage import LoginPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LoggerImpl
from selenium.webdriver.common.by import By

logger = LoggerImpl().get_logger(__name__)

class Test_001_Login:
    baseURL = ReadConfig.getApplicationUrl()
    username = ReadConfig.getAdminUsername()
    password = ReadConfig.getAdminPassword()



    @pytest.mark.regression
    def test_6683_FTS_Linq_URL_Verification(self,setup):
        logger.info("Open browser")
        logger.info("Enter link https://ftslinq-qa.corp.cvscaremark.com")
        self.driver = setup
        self.driver.get(self.baseURL)
        act_title=self.driver.title
        print("act_title:",act_title)

        if act_title=="FTS Linq":

            self.driver.close()
            assert True
            logger.info("Sign In page should be open.")
            logger.info("Test Case Passed")
        else:
            self.driver.save_screenshot(".\\Screenshots\\"+"URLVerification.png")
            self.driver.close()
            logger.error("Test Case Failed")
            assert False

    def test_6649_Verify_login_with_valid_username_and_valid_password(self,setup):
        logger.info("******** Verifying login functionality *********")
        self.driver = setup
        logger.info("Open the link ftslinq-qa.corp.cvscaremark.com")
        self.driver.get(self.baseURL)

        self.lp=LoginPage(self.driver)
        logger.info("Clicking on Login Link then Sign in page opens.")
        self.lp.clickOnLoginLink()
        time.sleep(2)
        logger.info("Sign in with valid username and valid password")
        self.lp.login(self.username, self.password)
        
        time.sleep(5)
        act_title = self.driver.find_element(By.XPATH, "//h3[contains(.,'My Dashboard » FTS Linq Admin')]").text
        print("act_title:", act_title)

        if act_title:
            self.driver.close()
            assert True
            logger.info("Login should be successful and control should go on home page. " +act_title+ "")
            logger.info("Test Case Passed")
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "Login.png")
            self.driver.close()
            logger.error("Test Case Failed")
            assert False