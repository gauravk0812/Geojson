import time

import pytest

from FTSLinqAutomation.Pages.AdministrationMenu.MenuItems import Administration
from Pages.LoginPage import LoginPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LoggerImpl
from selenium.webdriver.common.by import By

logger = LoggerImpl().get_logger(__name__)

class TestSelectMenuItems:
    baseURL = ReadConfig.getApplicationUrl()
    username = ReadConfig.getAdminUsername()
    password = ReadConfig.getAdminPassword()

    def test_Manage_Staff_link_from_Administration_menu_list(self,setup):
        logger.info("Open browser")
        logger.info("Enter link https://ftslinq-qa.corp.cvscaremark.com")
        self.driver = setup
        self.driver.get(self.baseURL)

        self.lp=LoginPage(self.driver)
        logger.info("Clicking on Login Link then Sign in page opens.")
        self.lp.clickOnLoginLink()
        self.driver.implicitly_wait(10) 
        logger.info("Sign in with valid username and valid password")
        self.lp.login(self.username, self.password)
        time.sleep(10)
        logger.info("Clicking on Manage Staff option from Administration menu")
        self.adminMenu = Administration(self.driver) 
        self.adminMenu.clickOnmanageStaffOption()
        time.sleep(5)

        actualPageTitle = self.driver.find_element(By.XPATH, "//h1[normalize-space()='Manage Staff']").text
        print(actualPageTitle)

        expectedPageTitle = "Manage Staff"

        if(actualPageTitle == expectedPageTitle):
            self.driver.close()
            assert True
            logger.info("User is successfully navigated to " +actualPageTitle+ " page")
            logger.info("Test Case Passed")
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "ManageStaff.png")
            self.driver.close()
            logger.error("Test Case Failed")
            assert False