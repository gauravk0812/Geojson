import random
import string
import time
import pytest
from FTSLinqAutomation.Pages.AdministrationMenu.ManageStaff.NewHireTracking.AddNewHireTracking import AddNewHireTracking
from FTSLinqAutomation.Pages.AdministrationMenu.ManageStaff.NewHireTracking.AdvancedSearch import AdvancedSearch
from FTSLinqAutomation.Pages.AdministrationMenu.ManageStaff.NewHireTracking.EditNewHireTracking import EditNewHireTracking
from FTSLinqAutomation.Pages.AdministrationMenu.MenuItems import Administration
from FTSLinqAutomation.testcases.AdministrationMenu.ManageStaff.NewHireTracking.test_AddNewHireTracking import random_generator_requisitionNumber
from Pages.LoginPage import LoginPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LoggerImpl
from selenium.webdriver.common.by import By

logger = LoggerImpl().get_logger(__name__)

class TestUpdateNewHireTracking:
    baseURL = ReadConfig.getApplicationUrl()
    username = ReadConfig.getAdminUsername()
    password = ReadConfig.getAdminPassword()

    #--------------Clicking on edit pencil icon from New Hire Tracking list page------------------------------------
    def test_Clicking_on_edit_pencil_icon_from_New_Hire_Tracking_Page_should_redirect_to_Update_New_Hire_Tracking_page(self, setup):
        logger.info("Open browser")
        logger.info("Enter link https://ftslinq-qa.corp.cvscaremark.com")
        self.driver = setup
        self.driver.get(self.baseURL)

        self.lp=LoginPage(self.driver)
        logger.info("Clicking on Login Link then Sign in page opens.")
        self.lp.clickOnLoginLink()
        self.driver.implicitly_wait(10) 
        logger.info("Sign in with valid username and valid password")
        self.lp.login(self.username, self.password)
        time.sleep(10)
        logger.info("Clicking on Manage Staff option from Administration menu")
        self.adminMenu = Administration(self.driver) 
        self.adminMenu.clickOnmanageStaffOption()
        
        time.sleep(5)
        logger.info("Clicking advanced search icon of New Hire Tracking")
        self.advancedSearch = AdvancedSearch(self.driver)
        self.advancedSearch.clickOnAdvancedSearchIcon()
        time.sleep(2)
        logger.info("Appying filter for 'Wait' Req status")
        self.advancedSearch.selectWaitReqStatusFilterOptions()
        logger.info("Clicking on search button")
        self.advancedSearch.clickOnSearchButton()
        time.sleep(3)
        logger.info("Clicking on edit oencil icon")
        self.editNewHireTracking = EditNewHireTracking(self.driver)
        self.editNewHireTracking.clickOnEditIcon()
        logger.info("User should be able to click on edit pencil icon")
        logger.info("User should redirect to Update New Hire Tracking page")

        logger.info("Change Req Status from Wait to Submitted")
        time.sleep(3)
        self.editNewHireTracking.changeRequisitionStatusToSubmitted()
        logger.info("User should be able to change the Req status from Wait to Submitted")

        logger.info("Clicking on Update Button")
        time.sleep(2)
        self.editNewHireTracking.clickOnUpdateButton()
        logger.info("User should be able to click on update button and the record should get updated")

    @pytest.mark.smoke
    def test_clicking_on_update_button_after_selecting_Req_status_Approved_and_New_Hire_Status_Able_to_Start_confirmed_should_open_Proceed_To_Start_Onboarding_popup(self, setup):
        logger.info("Open browser")
        logger.info("Enter link https://ftslinq-qa.corp.cvscaremark.com")
        self.driver = setup
        self.driver.get(self.baseURL)

        self.lp=LoginPage(self.driver)
        logger.info("Clicking on Login Link then Sign in page opens.")
        self.lp.clickOnLoginLink()
        self.driver.implicitly_wait(10) 
        logger.info("Sign in with valid username and valid password")
        self.lp.login(self.username, self.password)
        time.sleep(10)
        logger.info("Clicking on Manage Staff option from Administration menu")
        self.adminMenu = Administration(self.driver) 
        self.adminMenu.clickOnmanageStaffOption()
        
        time.sleep(5)
        logger.info("Clicking advanced search icon of New Hire Tracking")
        self.advancedSearch = AdvancedSearch(self.driver)
        self.advancedSearch.clickOnAdvancedSearchIcon()
        time.sleep(2)
        
        logger.info("Appying filter for 'Submitted' Req status")
        self.advancedSearch.selectSubmittedReqStatusFilterOptions()
        time.sleep(2)
        logger.info("Clicking on search button")
        self.advancedSearch.clickOnSearchButton()
        time.sleep(3)
        logger.info("Clicking on edit oencil icon")
        self.editNewHireTracking = EditNewHireTracking(self.driver)
        self.editNewHireTracking.clickOnEditIcon()
        logger.info("User should be able to click on edit pencil icon")
        logger.info("User should redirect to Update New Hire Tracking page")

        logger.info("Change Req Status Submitted to Approved")
        time.sleep(3)
        self.editNewHireTracking.changeRequisitionStatusToApproved()
        logger.info("User should be able to change the Req status from Wait to Submitted")

        logger.info("select new hire tracking status 'Able To Start Confirmed'")
        self.editNewHireTracking.selectNewHireStatusAbleToStartConfirmed()
        time.sleep(2)
        logger.info("User should be able to select new hire tracking status as 'Able To Start Confirmed'")
        logger.info("Fields Requisition Number, New Hire First Name, New Hire last Name and Tentative Start Date should become mandatory")
        self.addNewHiretRacking = AddNewHireTracking(self.driver)
        reqNumber = random_generator_requisitionNumber()
        self.addNewHiretRacking.enterRequisitionNumber("REQ-"+reqNumber)
        self.addNewHiretRacking.enterNewHireFirstNameandLastName("John", "Daley")
        time.sleep(3)
        self.addNewHiretRacking.selectTentativeStartDate()
        time.sleep(2)
        logger.info("User should be able ti fill new hire tracking first name, new hire tracking last name and tentative start date")
        logger.info("Clicking on Update Button")
        self.editNewHireTracking.clickOnUpdateButton()
        logger.info("User should be able to click on update button and the record should get updated")

        popupAlert = self.driver.find_element(By.XPATH, "//h2[.='Proceed with Onboarding']").text
        print(popupAlert)
        if(popupAlert == "Proceed with Onboarding" ):
            self.driver.close()
            logger.info("Test Case Passed")
            assert True

        else:
            self.driver.close()
            logger.info("Test Case Failed")
            assert False
        


    #def test_clicking_on_yes_button_of_Proceed_To_Start_Onboarding_should_open_a_new_popup_Onboard_New_Staff(self,setup):
