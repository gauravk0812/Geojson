import time
import pytest
from FTSLinqAutomation.Pages.AdministrationMenu.ManageStaff.NewHireTracking.AdvancedSearch import AdvancedSearch
from FTSLinqAutomation.Pages.AdministrationMenu.MenuItems import Administration
from Pages.LoginPage import LoginPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LoggerImpl
from selenium.webdriver.common.by import By

logger = LoggerImpl().get_logger(__name__)

class TestAddNewHireTracking:
    baseURL = ReadConfig.getApplicationUrl()
    username = ReadConfig.getAdminUsername()
    password = ReadConfig.getAdminPassword()

    #--------------Clicking on plus icon from New Hire Tracking list page------------------------------------
    def test_Clicking_on_add_button_from_New_Hire_Tracking_Page_should_redirect_to_New_Hire_Tracking_Editor_page(self, setup):
        logger.info("Open browser")
        logger.info("Enter link https://ftslinq-qa.corp.cvscaremark.com")
        self.driver = setup
        self.driver.get(self.baseURL)

        self.lp=LoginPage(self.driver)
        logger.info("Clicking on Login Link then Sign in page opens.")
        self.lp.clickOnLoginLink()
        self.driver.implicitly_wait(10) 
        logger.info("Sign in with valid username and valid password")
        self.lp.login(self.username, self.password)
        time.sleep(10)
        logger.info("Clicking on Manage Staff option from Administration menu")
        self.adminMenu = Administration(self.driver) 
        self.adminMenu.clickOnmanageStaffOption()
        
        time.sleep(5)
        logger.info("Clicking on New Hire Tracking Tab")
        self.advancedSearch = AdvancedSearch(self.driver)
        self.advancedSearch.clickOnAdvancedSearchIcon()
        time.sleep(2)
        self.advancedSearch.selectReqStatusFilterOptions()
        self.advancedSearch.clickOnSearchButton()
        time.sleep(3)
        
        chip = self.driver.find_element(By.XPATH, "//span[contains(text(),'Wait')]").is_displayed() 

        if chip == True:
            self.driver.close()
            assert True
            logger.info("Filter applied successfully and 'Wait' chip is displayed.")
            logger.info("Test Case Passed")
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "test_Clicking_on_add_button_from_New_Hire_Tracking_Page_should_redirect_to_New_Hire_Tracking_Editor_page.png")
            self.driver.close()
            assert False
            

