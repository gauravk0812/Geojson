import random
import string
import time

import pytest


from FTSLinqAutomation.Locators.commonLocators import CommonLocators
from FTSLinqAutomation.Pages.AdministrationMenu.ManageStaff.NewHireTracking.AddNewHireTracking import AddNewHireTracking
from FTSLinqAutomation.Pages.AdministrationMenu.MenuItems import Administration
from Pages.LoginPage import LoginPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LoggerImpl
from selenium.webdriver.common.by import By

logger = LoggerImpl().get_logger(__name__)

class TestAddNewHireTracking:
    baseURL = ReadConfig.getApplicationUrl()
    username = ReadConfig.getAdminUsername()
    password = ReadConfig.getAdminPassword()

    #--------------Clicking on plus icon from New Hire Tracking list page------------------------------------
    def test_Clicking_on_add_button_from_New_Hire_Tracking_Page_should_redirect_to_New_Hire_Tracking_Editor_page(self, setup):
        logger.info("Open browser")
        logger.info("Enter link https://ftslinq-qa.corp.cvscaremark.com")
        self.driver = setup
        self.driver.get(self.baseURL)

        self.lp=LoginPage(self.driver)
        logger.info("Clicking on Login Link then Sign in page opens.")
        self.lp.clickOnLoginLink()
        self.driver.implicitly_wait(10) 
        logger.info("Sign in with valid username and valid password")
        self.lp.login(self.username, self.password)
        time.sleep(10)
        logger.info("Clicking on Manage Staff option from Administration menu")
        self.adminMenu = Administration(self.driver) 
        self.adminMenu.clickOnmanageStaffOption()
        
        time.sleep(5)
        logger.info("Clicking on New Hire Tracking Tab")
        self.newHireTracking = AddNewHireTracking(self.driver)
        self.newHireTracking.clickOnNewHireTrackingTab()
        logger.info("User is redirected to the tab")
        time.sleep(2)
        logger.info("Clicking on Add button")
        self.newHireTracking.clickOnAddButton()
        time.sleep(2)

        actualPageTitle = self.driver.find_element(By.ID, "new-hire-tracking-title").text

        expectedPageTitle = "New Hire Tracking"

        if(actualPageTitle == expectedPageTitle):
            self.driver.close()
            assert True
            logger.info("User redirected to " +actualPageTitle+ ".")
            logger.info("Test Case Passed")
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "Login.png")
            self.driver.close()
            logger.error("Test Case Failed")
            assert False
    
    #---------------------------Add New Hire Tracking---------------------------------
    @pytest.mark.regression
    def test_clicking_on_save_button_of_new_hire_tracking_add_page_with_requisition_status_wait_should_save_the_record(self, setup):
        logger.info("Open browser")
        logger.info("Enter link https://ftslinq-qa.corp.cvscaremark.com")
        self.driver = setup
        self.driver.get(self.baseURL)
        #----- Signing In -------------
        self.lp=LoginPage(self.driver)
        logger.info("Clicking on Login Link then Sign in page opens.")
        self.lp.clickOnLoginLink()
        self.driver.implicitly_wait(10) 
        logger.info("Sign in with valid username and valid password")
        self.lp.login(self.username, self.password)
        
        #----------- moving to Manage Staff from Administration Menu ------------
        logger.info("Clicking on Manage Staff option from Administration menu")
        self.adminMenu = Administration(self.driver) 
        self.adminMenu.wait_for_element_visible(CommonLocators.icon_administration_menu)
        self.adminMenu.clickOnmanageStaffOption()
        time.sleep(5)
        #----------- New Hire Tracking----------
        logger.info("Clicking on New Hire Tracking Tab")
        self.newHireTracking = AddNewHireTracking(self.driver)
        self.newHireTracking.wait_for_element_visible(CommonLocators.tab_newHireTracking)
        self.newHireTracking.clickOnNewHireTrackingTab()
        logger.info("User is redirected to the tab")
        time.sleep(2)
        logger.info("Clicking on Add button")
        self.newHireTracking.clickOnAddButton()
        time.sleep(2)
        logger.info("User should redirect to new hire tracking editor page")
        #------------ Add New Hire Tracking ---------------
        logger.info("Filling new hire tracking details")
        logger.info("Selecting direct manager")
        self.newHireTracking.selectDirectManager()
        time.sleep(2)
        logger.info("User should be able to select direct manager from dropdown")

        logger.info("Select Team")
        self.newHireTracking.selectTeam()
        time.sleep(2)
        logger.info("User should be able to select team from dropdown")
        
        logger.info("Entering Requisition Number")
        reqNum = random_generator_requisitionNumber()
        self.newHireTracking.enterRequisitionNumber("REQ-" +reqNum)
        logger.info("User should be able to fill requisition number")

        logger.info("Entering home city and home state")
        self.newHireTracking.enterHomeCityandState("Los Angeles", "California")
        logger.info("User should be able to fill city and state")

        logger.info("selecting title")
        self.newHireTracking.selectTitle()
        time.sleep(2)
        logger.info("User should be able to select title")

        logger.info("Entering first name and last name")
        self.newHireTracking.enterNewHireFirstNameandLastName("Robert", "Methew")
        logger.info("User should be able to enter first name and last name")

        '''logger.info("Selecting tentative date")
        self.newHireTracking.selectTentativeStartDate()
        time.sleep(10)
        logger.info("User should be able to select tentative date")'''

        logger.info("Clicking on save button")
        self.newHireTracking.clickOnSaveButton()
        logger.info("User should be able to click on save button")
        time.sleep(5)
        
        actualPageTitle = self.driver.find_element(By.XPATH, "//div[.='Manage Staff']").text

        expectedPageTitle = "Manage Staff"

        if(actualPageTitle == expectedPageTitle):
            self.driver.close()
            assert True
            logger.info("User redirected to " +actualPageTitle+ ", and new hire trcaking is saved successfully.")
            logger.info("Test Case Passed")
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "Login.png")
            self.driver.close()
            logger.error("Test Case Failed")
            assert False   

def random_generator_requisitionNumber(size=10, chars= string.digits):
    return ''.join(random.choice(chars) for x in range(size))