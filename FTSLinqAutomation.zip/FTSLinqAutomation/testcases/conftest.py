import logging
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from FTSLinqAutomation.utilities.customLogger import setup_logging


# ---------------- DRIVER FIXTURE ---------------- #

@pytest.fixture()
def setup(browser):
    driver = None

    # ----- Chrome -----
    if browser.lower() == "chrome":
        driver = webdriver.Chrome()
        print("Launching Chrome...")
        driver.maximize_window()

    # ----- Firefox -----
    elif browser.lower() == "firefox":
        driver = webdriver.Firefox()
        print("Launching Firefox...")
        driver.maximize_window()

    # ----- Opera using Chromium mode -----
    elif browser.lower() == "chromium":
        opera_path = r"C:\Users\Priya Soni\AppData\Local\Programs\Opera\opera.exe"
        driver_path = r"C:\ChromeDriver\chromedriver-win64 (3)\chromedriver-win64\chromedriver.exe"

        chrome_options = Options()  
        chrome_options.binary_location = opera_path

        service = Service(driver_path)

        driver = webdriver.Chrome(service=Service, options=chrome_options)
        print("Launching Opera (Chromium mode)...")
        driver.maximize_window()

    # ----- IE -----
    elif browser.lower() == "ie":
        driver = webdriver.Ie()
        print("Launching Internet Explorer...")
        driver.maximize_window()

    else:
        raise ValueError(f"Unsupported browser: {browser}")

    return driver


# ---------------- BROWSER CLI OPTION ---------------- #

def pytest_addoption(parser):
    parser.addoption("--browser")


@pytest.fixture()
def browser(request):
    return request.config.getoption("--browser")


# ---------------- LOGGING SETUP ---------------- #

@pytest.fixture(scope="session", autouse=True)
def configure_logging():
    setup_logging()
    yield
    logging.shutdown()


# ---------------- PYTEST HTML REPORT ---------------- #

@pytest.hookimpl(tryfirst=True)
def pytest_configure(config):
    if not hasattr(config, "_metadata"):
        config._metadata = {}

    config._metadata["Project Name"] = "FTS_Linq"
    config._metadata["Module Name"] = "Test"
    config._metadata["Tester"] = "Priya Soni"


@pytest.hookimpl(optionalhook=True)
def pytest_metadata(metadata):
    metadata["Project Name"] = "FTS_Linq"
    metadata["Module Name"] = "Test"
    metadata["Tester"] = "Priya Soni"

    # Clean unwanted fields
    metadata.pop("Plugins", None)
    metadata.pop("Packages", None)
