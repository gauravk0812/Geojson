from selenium.webdriver.common.by import By

class CommonLocators:

    # Ids of all the menu
    icon_administration_menu = (By.XPATH, "//mat-icon[normalize-space()='admin_panel_settings']")

    # Locators of all the menu items

    listitem_manageUser = (By.XPATH, "//span[contains(text(),'Manage Users')]")
    listitem_manageStaff = (By.XPATH, "//span[contains(text(),'Manage Staff')]")

    # Locators of all the common tabs

    tab_newHireTracking = (By.XPATH, "//span[contains(text(),'New Hire Tracking')]")
    