import random
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.keys import Keys
from sqlalchemy import Select





class BasePage:
    def __init__(self, driver, timeout=10):
        self.driver = driver
        self.timeout = timeout

    def find_element(self, locator):
        try:
            return WebDriverWait(self.driver, self.timeout).until(
                EC.visibility_of_element_located(locator)
            )
        except TimeoutException:
            raise Exception(f"Element with locator {locator} not found")

    def find_elements(self, locator):
        try:
            return WebDriverWait(self.driver, self.timeout).until(
                EC.presence_of_all_elements_located(locator)
            )
        except TimeoutException:
            raise Exception(f"Elements with locator {locator} not found")

    def click(self, locator):
        element = self.find_element(locator)
        element.click()

    '''def clickCommonElement(self, locator):
        element = self.find_element(locator)
        element.click()'''

    def send_keys(self, locator, text):
        element = self.find_element(locator)
        #element.clear()
        element.send_keys(Keys.CONTROL, 'a')
        element.send_keys(Keys.DELETE)
        element.send_keys(text)
    
    '''def send_keys(self, locator, text):
        """Clear textbox and send keys (handles React/Vite inputs)"""
        element = self.wait.until(EC.element_to_be_clickable(locator))
        
        # Standard clear
        element.clear()

        # If still not empty (React-controlled inputs)
        if element.get_attribute("value") != "":
            self.driver.execute_script("arguments[0].value = '';", element)

        element.send_keys(text)
        return element'''

    def get_text(self, locator):
        element = self.find_element(locator)
        return element.text

    def is_displayed(self, locator):
        try:
            return self.find_element(locator).is_displayed()
        except Exception:
            return False
        
    def is_editable(self, locator):
        try:
            return self.find_element(locator).is_enabled()
        except Exception:
            return False

    def wait_for_element_visible(self, locator):
        return WebDriverWait(self.driver, self.timeout).until(
            EC.visibility_of_element_located(locator)
        )


