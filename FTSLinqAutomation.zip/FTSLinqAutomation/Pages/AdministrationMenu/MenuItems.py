from asyncio import timeout

from selenium.webdriver.common.by import By
from FTSLinqAutomation.Locators.commonLocators import CommonLocators
from FTSLinqAutomation.Pages.BasePage import BasePage

class Administration(BasePage):
    
    
    def clickOnmanageStaffOption(self):
        self.click(CommonLocators.icon_administration_menu)
        self.click(CommonLocators.listitem_manageStaff)

