import time
from FTSLinqAutomation.Locators.commonLocators import CommonLocators
from FTSLinqAutomation.Pages.BasePage import BasePage
from selenium.webdriver.common.by import By


class EditNewHireTracking(BasePage):

    icon_editNewHireTracking = (By.XPATH, "//tbody/tr[1]/td[14]/mat-icon[2]")

    #------------------- Requisition Status----------------
    dropdown_requisitionStatus = (By.ID, "req_status")
    option_requisitionStatus_submitted = (By.XPATH, "//span[.=' Submitted ']")
    option_requisitionStatus_closed = (By.XPATH, "//span[.=' Closed ']")
    option_requisitionStatus_approved = (By.XPATH, "//span[.=' Approved ']")
    option_requisitionStatus_wait = (By.XPATH, "//span[.=' Wait ']")

    #----------------------New Hire Status-----------------

    dropdown_newHireStatus = (By.ID, "new_hire_status")
    option_newHireStatus_AbleToStartConfirmed = (By.XPATH, "//span[.=' Able To Start Confirmed ']")
    

    button_update = (By.ID, "update-button")
    button_cancel = (By.ID, "cancel-button")

    #--------------- Start Onboarding popup------------
    popup_confirmationAlert = (By.XPATH, "//p[contains(text(),'Do you want to proceed with onboarding for Satish ')]") 

    def clickOnEditIcon(self):
        self.click(self.icon_editNewHireTracking)

    def changeRequisitionStatusToSubmitted(self):
        self.click(self.dropdown_requisitionStatus)
        time.sleep(2)
        self.click(self.option_requisitionStatus_submitted)

    def changeRequisitionStatusToApproved(self):
        self.click(self.dropdown_requisitionStatus)
        time.sleep(2)
        self.click(self.option_requisitionStatus_approved)

    def selectNewHireStatusAbleToStartConfirmed(self):
        self.click(self.dropdown_newHireStatus)
        time.sleep(2)
        self.click(self.option_newHireStatus_AbleToStartConfirmed)

    def clickOnUpdateButton(self):
        self.click(self.button_update)

    def clickOnCancelButton(self): 
        self.click(self.button_cancel)