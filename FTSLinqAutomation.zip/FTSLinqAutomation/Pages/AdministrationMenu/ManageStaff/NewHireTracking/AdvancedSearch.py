import time
from FTSLinqAutomation.Locators.commonLocators import CommonLocators
from FTSLinqAutomation.Pages.BasePage import BasePage
from selenium.webdriver.common.by import By


class AdvancedSearch(BasePage):

    icon_advancedSearch = (By.XPATH, "//mat-icon[normalize-space()='filter_alt']")
    # Zone filter options of advanced search

    advancedsearch_zone = (By.ID, "zone")
    adsearch_zonePanel = (By.ID, "zone-panel")
    adsearch_zone_selectall = (By.XPATH, "//label[.=' Select All ']")
    adsearch_zone_zone0 = (By.ID, "0")
    adsearch_zone_zone1 = (By.ID, "1")
    adsearch_zone_zone2 = (By.ID, "2")
    adsearch_zone_zone3 = (By.ID, "3")
    adsearch_zone_zone4 = (By.ID, "4")
    adsearch_zone_zone5 = (By.ID, "5")
    adsearch_zone_zone6 = (By.ID, "6")
    adsearch_zone_zone7 = (By.ID, "7")
    adsearch_zone_zone9 = (By.ID, "9")


    # Req Status filter options of advanced search
    advancedsearch_reqStatus = (By.XPATH, "//mat-label[normalize-space()='Req Status']")
    adsearch_reqstatus_approved = (By.XPATH, "//span[contains(.,'Approved')]")
    adsearch_reqstatus_closed = (By.XPATH, "//span[.=' Closed ']")
    adsearch_reqstatus_submitted = (By.XPATH, "//span[.=' Submitted ']")
    adsearch_reqstatus_wait = (By.XPATH, "//span[.=' Wait ']")

    # New hire status filter options of advanced search
    advancedsearch_newhirestatus = (By.XPATH, "//mat-label[.='New Hire Status']")
    adsearch_newhirestatus_abletostartconfirmed = (By.XPATH, "//span[.=' Able To Start Confirmed ']")
    adsearch_newhirestatus_employeestarted = (By.XPATH, "//span[.=' Employee Started ']")
    adsearch_newhirestatus_inbackground = (By.XPATH, "//span[.=' In Background ']")
    adsearch_newhirestatus_indispute = (By.XPATH, "//span[.=' In Dispute ']")
    adsearch_newhirestatus_offerpending = (By.XPATH, "//span[.=' Offer Pending ']")
    adsearch_newhirestatus_onboardingstarted = (By.XPATH, "//span[.=' Onboarding Started ']")
    adsearch_newhirestatus_recruiting = (By.XPATH, "//span[.=' Recruiting ']")
    adsearch_newhirestatus_talktodirectorfirst = (By.XPATH, "//span[.=' Talk To Director First ']")

    # Buttons
    button_search = (By.XPATH, "//span[.=' Search ']")
    button_cancel = (By.XPATH, "//span[.=' Cancel ']")

    def clickOnAdvancedSearchIcon(self):
        self.click(CommonLocators.tab_newHireTracking)
        time.sleep(2)
        self.click(self.icon_advancedSearch)

    def selectZoneFilterOptions(self, text):
        self.click(self.advancedsearch_zone)

        self.click(self.adsearch_zone_selectall)
        time.sleep(2)
        self.click(self.adsearch_zone_zone0)
        time.sleep(2)
        self.click(self.adsearch_zone_zone1)
        time.sleep(2)
        self.click(self.adsearch_zone_zone2)
        time.sleep(2)
        self.click(self.adsearch_zone_zone3)
        time.sleep(2)
        self.click(self.adsearch_zone_zone4)
        time.sleep(2)
        self.click(self.adsearch_zone_zone5)
        time.sleep(2)
        self.click(self.adsearch_zone_zone6)
        time.sleep(2)
        self.click(self.adsearch_zone_zone7)
        time.sleep(2)
        self.click(self.adsearch_zone_zone9)
        time.sleep(2)
    
    def selectWaitReqStatusFilterOptions(self):
        self.click(self.advancedsearch_reqStatus)
        time.sleep(2)
        self.click(self.adsearch_reqstatus_wait)
        time.sleep(2)

    def selectApprovedReqStatusFilterOptions(self):
        self.click(self.advancedsearch_reqStatus)
        time.sleep(2)
        self.click(self.adsearch_reqstatus_approved)
        time.sleep(2)
        
    def selectSubmittedReqStatusFilterOptions(self):
        self.click(self.advancedsearch_reqStatus)
        time.sleep(2)
        self.click(self.adsearch_reqstatus_submitted)
        time.sleep(2)
    
    def selectClosedReqStatusFilterOptions(self):
        self.click(self.advancedsearch_reqStatus)
        time.sleep(2)
        self.click(self.adsearch_reqstatus_closed)
        time.sleep(2)
        
    

    def selectNewHireStatusFilterOptions(self):
        self.click(self.advancedsearch_newhirestatus)
        time.sleep(2)
        self.click(self.adsearch_newhirestatus_abletostartconfirmed)
        time.sleep(2)

    def selectNewHireStatusFilterOptions(self):
        self.click(self.advancedsearch_newhirestatus)
        time.sleep(2)
        self.click(self.adsearch_newhirestatus_employeestarted)
        time.sleep(2)

    def selectNewHireStatusFilterOptions(self):
        self.click(self.advancedsearch_newhirestatus)
        time.sleep(2)
        self.click(self.adsearch_newhirestatus_inbackground)
        time.sleep(2)

    def selectNewHireStatusFilterOptions(self):
        self.click(self.advancedsearch_newhirestatus)
        time.sleep(2)
        self.click(self.adsearch_newhirestatus_indispute)
        time.sleep(2)

    def selectNewHireStatusFilterOptions(self):
        self.click(self.advancedsearch_newhirestatus)
        time.sleep(2)
        self.click(self.adsearch_newhirestatus_offerpending)
        time.sleep(2)
    
    def selectNewHireStatusFilterOptions(self):
        self.click(self.advancedsearch_newhirestatus)
        time.sleep(2)
        self.click(self.adsearch_newhirestatus_onboardingstarted)
        time.sleep(2)

    
    def selectNewHireStatusFilterOptions(self):
        self.click(self.advancedsearch_newhirestatus)
        time.sleep(2)
        self.click(self.adsearch_newhirestatus_recruiting)
        time.sleep(2)

    def selectNewHireStatusFilterOptions(self):
        self.click(self.advancedsearch_newhirestatus)
        time.sleep(2)
        self.click(self.adsearch_newhirestatus_talktodirectorfirst)
        time.sleep(2)

    def clickOnSearchButton(self):
        self.click(self.button_search)

    def clickOnCancelButton(self):
        self.click(self.button_cancel)
