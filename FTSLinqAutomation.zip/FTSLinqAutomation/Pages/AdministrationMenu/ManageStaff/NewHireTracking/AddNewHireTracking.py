import time
from FTSLinqAutomation.Locators.commonLocators import CommonLocators
from FTSLinqAutomation.Pages.BasePage import BasePage
from selenium.webdriver.common.by import By


class AddNewHireTracking(BasePage):
    #----New Hire Tracking Tab---------
    #tab_newHireTracking = (By.XPATH, "//span[contains(text(),'New Hire Tracking')]")
    button_addNewHireTracking = (By.XPATH, "//mat-icon[normalize-space()='add']")

    #---------Add New Hire Tracking Elements------------
    dropdown_directManager = (By.ID, "manager")
    option_directManager = (By.XPATH, "//span[normalize-space()='Anthony Martorina']")
    dropdown_team = (By.ID, "team")
    option_team =(By.XPATH, "//span[normalize-space()='Team 1']")
    textbox_requisitionNumber = (By.ID, "req_number")
    #dropdown_requisitionStatus = (By.ID, "req_status")
    #option_requisitionStatus = (By.XPATH, "//span[.=' Approved ']")
    textbox_homeCity = (By.ID, "city")
    textbox_homeState = (By.ID, "state")
    dropdown_newHireStatus = (By.ID, "new_hire_status")
    dropdown_title = (By.ID, "title")
    option_title = (By.XPATH, "//span[normalize-space()='IS Technician']")
    textbox_newHireFirstName = (By.ID, "new_hire_first_name")
    textbox_newHirsLastName = (By.ID, "new_hire_last_name")

    #date_tentativeStartDate = (By.XPATH, "//mat-datepicker-toggle[@id='tentative-start-date-toggle']//span[@class='mat-mdc-focus-indicator']")
    date_tentativeStartDate = (By.ID, "tentative-start-date-toggle")
    tentativeStartDate_previousMonth = (By.XPATH, "//button[@aria-label='Previous month']//span[@class='mat-mdc-button-persistent-ripple mdc-icon-button__ripple']")
    tentativeStartDate_nextMonth = (By.XPATH, "//button[@aria-label='Next month']//span[@class='mat-focus-indicator']")
    tentativeStartDate_date =(By.XPATH, "//span[normalize-space()='20']")
    
    #--------Buttons----------
    button_save = (By.ID, "save-button")
    button_cancel = (By.ID, "cancel-button")


    def clickOnNewHireTrackingTab(self):
        self.click(CommonLocators.tab_newHireTracking)

    def clickOnAddButton(self):
        self.click(self.button_addNewHireTracking)

    def selectDirectManager(self):
        self.click(self.dropdown_directManager)
        time.sleep(2)
        self.click(self.option_directManager)

    def selectTeam(self):
        self.click(self.dropdown_team)
        time.sleep(2)
        self.click(self.option_team)

    def enterRequisitionNumber(self, requisitionNumber):
        self.send_keys(self.textbox_requisitionNumber, requisitionNumber)

    def enterHomeCityandState(self, city, state):
        self.send_keys(self.textbox_homeCity, city)
        self.send_keys(self.textbox_homeState, state)

    def selectTitle(self):
        self.click(self.dropdown_title)
        time.sleep(2)
        self.click(self.option_title)

    def enterNewHireFirstNameandLastName(self, firstName, lastName):
        self.send_keys(self.textbox_newHireFirstName, firstName)
        self.send_keys(self.textbox_newHirsLastName, lastName)

    def selectTentativeStartDate(self):
        self.click(self.date_tentativeStartDate)
        time.sleep(5)
        self.click(self.tentativeStartDate_nextMonth)
        time.sleep(5)
        self.click(self.tentativeStartDate_date)

    def clickOnSaveButton(self):
        self.click(self.button_save)

    def clickOnCancelButton(self):
        self.click(self.button_cancel)