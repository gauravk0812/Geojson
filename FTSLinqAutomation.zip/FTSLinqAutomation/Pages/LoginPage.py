from asyncio import timeout

from selenium.webdriver.common.by import By
from FTSLinqAutomation.Pages.BasePage import BasePage


class LoginPage(BasePage):
     linktext_login = (By.XPATH, "//span[.=' Sign in with a username and password ']")
     textbox_username = (By.XPATH, "//input[@formcontrolname='username']")
     textbox_password = (By.XPATH, "//input[@formcontrolname='password']")
     button_signin  = (By.XPATH, "//button[.=' Sign in ']")

     def clickOnLoginLink(self):
          self.click(self.linktext_login)

     def login(self,username,password):
        self.send_keys(self.textbox_username,username)
        self.send_keys(self.textbox_password,password)
        self.click(self.button_signin)

     